﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity;

namespace GamesStore
{
   public class GamesDB : DbContext
    {
        public GamesDB() : base("GamesConnect")
        {
        }
       public DbSet<Account> Accounts { get; set; }
       public DbSet<Admin> Admins { get; set; }
    }
}
