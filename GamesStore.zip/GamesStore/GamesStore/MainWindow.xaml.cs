﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Threading;

namespace GamesStore
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        GamesDB gamesDB = new GamesDB();
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Reg_Click(object sender, RoutedEventArgs e)
        {
            RegWin regWin = new RegWin();
            regWin.Show();
            Hide();
        }

        private void Input_Click(object sender, RoutedEventArgs e)
        {
            Thread thread = new Thread(()=>Lis(gamesDB));
            thread.Start();

        }

        public void Lis(GamesDB games)
        {
            this.Dispatcher.BeginInvoke(new Action(() =>
            {
                List<Account> accounts = games.Accounts.ToList();
                List<Admin> admins = games.Admins.ToList();
                
                foreach (var item in accounts)
                {
                    Account account = (item as Account);
                    if (t1.Text == account.Login && t2.Password.ToString() == account.Pass)
                    {
                        GamesMagWin win = new GamesMagWin(account);
                        win.Show();
                        Hide();
                        break;
                    }
                    else
                    {
                        
                        Random rnd = new Random();
                        Brush[] brushes = new Brush[] { Brushes.Red, Brushes.Black, Brushes.Violet};
                        Brush brush = brushes[rnd.Next(brushes.Length)];
                        d1.Foreground = brush;
                        d1.Visibility = Visibility.Visible;
                    }

                }

                foreach (var item1 in admins)
                {
                    Admin admin = (item1 as Admin);
                    if (t1.Text == admin.Log && t2.Password.ToString() == admin.Pass)
                    {
                        AdminGamesMagWin win = new AdminGamesMagWin(admin);
                        win.Show();
                        Hide();
                        break;
                    }
                    else
                    {

                        Random rnd = new Random();
                        Brush[] brushes = new Brush[] { Brushes.Red, Brushes.Black, Brushes.Violet };
                        Brush brush = brushes[rnd.Next(brushes.Length)];
                        d1.Foreground = brush;
                        d1.Visibility = Visibility.Visible;
                    }
                }
            }));
            
        }
    }
}
